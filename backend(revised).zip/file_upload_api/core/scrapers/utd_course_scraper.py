from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import mysql.connector
import re

def scrape_utd_courses():

    def get_db_connection():
        return mysql.connector.connect(
            host="localhost",
            user="root",
            password="admin",
            database="student"
        )

    def ensure_cs_courses_table():
        db = get_db_connection()
        cursor = db.cursor()
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS cs_courses (
                id INT AUTO_INCREMENT PRIMARY KEY,
                course_code VARCHAR(20) UNIQUE,
                course_title TEXT,
                keywords TEXT,
                course_level VARCHAR(20)
            )
        """)
        db.commit()
        cursor.close()
        db.close()

    def extract_keywords(text):
        text = text.lower()
        text = re.sub(r'\([^)]*(semester credit hours|same as|cross-listed|corequisite|prerequisite)[^)]*\)', '', text)
        text = re.sub(r'\(\d+-\d+\)', '', text)
        text = re.sub(r'\(\d+ semester credit hours\)', '', text)

        admin_phrases = [
            r'\d+ semester credit hour[s]?',
            r'lab fee.*?required',
            r'credit cannot be received.*?\.',
            r'may not be used.*?\.',
            r'(pre|co)requisite[s]?:?.*?\.',
            r'note that.*?\.',
            r'same as .*?\.',
            r'cross-listed.*?\.',
            r'repeatable for credit.*?\.',
            r'school of engineering and computer science',
            r'this class is open to students.*?only',
            r'a grade of [a-z] or better in .*? is required.*?\.',
            r'students will also be registered for an exam section.*?\.',
            r'students will be required to participate.*?\.',
            r'during the course.*?\.',
            r'this class is restricted to .*?\.',
            r'satisfy.*?requirement[s]?.*?\.',
            r'requirement[s]? for.*?\.',
            r'the class is open to students in .*? only',
            r'a grade of .*? is required to register for .*?\.',
            r'students will also be registered for .*?\.',
            r'additional preparatory topics for .*? majors',
            r'or can substitute for this course.*?\.',
            r'may substitute for this course.*?\.',
            r'or .*? may substitute for .*?\.',
            r'this course can substitute for .*?\.'
        ]
        for pattern in admin_phrases:
            text = re.sub(pattern, '', text)

        text = re.sub(r'\b[a-z]{2,4}\s?\d{4}\b', '', text)
        text = re.sub(r'\(\s*\)', '', text)
        text = re.sub(r'\.\s*\.', '.', text)
        text = re.sub(r'\s+', ' ', text).strip()

        return [t.strip() for t in text.split('.') if len(t.strip().split()) > 2]

    def insert_course(course_code, course_title, keywords_combined, level):
        db = get_db_connection()
        cursor = db.cursor()
        try:
            cursor.execute(
                "INSERT INTO cs_courses (course_code, course_title, keywords, course_level) VALUES (%s, %s, %s, %s)",
                (course_code, course_title, keywords_combined, level)
            )
            db.commit()
        except mysql.connector.IntegrityError:
            pass
        finally:
            cursor.close()
            db.close()

    def process_courses(driver, level):
        WebDriverWait(driver, 15).until(
            EC.presence_of_all_elements_located((By.CSS_SELECTOR, "article.page-body p[id^='cs']"))
        )
        courses = driver.find_elements(By.CSS_SELECTOR, "article.page-body p[id^='cs']")
        for course in courses:
            try:
                course_code = course.find_element(By.CLASS_NAME, "course_address").text.strip()
                course_title = course.find_element(By.CLASS_NAME, "course_title").text.strip()
                full_text = course.text.strip()
            except:
                continue

            description = full_text
            for part in [course_code, course_title]:
                description = description.replace(part, "")
            description = re.sub(r'\(\d+ semester credit hours\)', '', description).strip()
            keyword_phrases = extract_keywords(description)
            if not keyword_phrases:
                continue

            keywords_combined = ' || '.join(keyword_phrases)
            insert_course(course_code, course_title, keywords_combined, level)

    def main():
        ensure_cs_courses_table()
        options = Options()
        options.add_argument("--start-maximized")
        driver = webdriver.Chrome(options=options)

        # Undergraduate Catalog
        driver.get("https://catalog.utdallas.edu/")
        try:
            WebDriverWait(driver, 10).until(EC.presence_of_all_elements_located((By.CSS_SELECTOR, "a")))
            links = driver.find_elements(By.CSS_SELECTOR, "a")
            ug_links = [(l.text.strip(), l) for l in links if re.match(r"20\d{2} Undergraduate Catalog", l.text.strip())]
            ug_links.sort(key=lambda x: x[0], reverse=True)
            ug_links[0][1].click()
        except:
            driver.quit()
            return

        try:
            driver.find_element(By.LINK_TEXT, "Undergraduate Courses").click()
            driver.find_element(By.LINK_TEXT, "Undergraduate Courses by Subject").click()
            driver.find_element(By.PARTIAL_LINK_TEXT, "CS").click()
            process_courses(driver, "Undergraduate")
        except:
            pass

        # Graduate Catalog
        driver.get("https://catalog.utdallas.edu/")
        try:
            WebDriverWait(driver, 10).until(EC.presence_of_all_elements_located((By.CSS_SELECTOR, "a")))
            links = driver.find_elements(By.CSS_SELECTOR, "a")
            grad_links = [(l.text.strip(), l) for l in links if re.match(r"20\d{2} Graduate Catalog", l.text.strip())]
            grad_links.sort(key=lambda x: x[0], reverse=True)
            grad_links[0][1].click()
        except:
            driver.quit()
            return

        try:
            driver.find_element(By.LINK_TEXT, "Graduate Courses").click()
            driver.find_element(By.LINK_TEXT, "Graduate Courses by Subject").click()
            driver.find_element(By.PARTIAL_LINK_TEXT, "CS").click()
            process_courses(driver, "Graduate")
        except:
            pass

        with open("selenium_output.html", "w", encoding="utf-8") as f:
            f.write(driver.page_source)

        driver.quit()

    main()
