from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from django.core.files.storage import FileSystemStorage
from django.conf import settings
import os
import pandas as pd
from .models import GraderAssignment
from .serializers import GraderAssignmentSerializer, FileUploadSerializer



#  Receives and stores uploaded files in their respective folders
class FileUploadAPI(APIView):
    def post(self, request):
        serializer = FileUploadSerializer(data=request.data)
        if serializer.is_valid():
            uploaded_file = serializer.validated_data['file']
            file_type = serializer.validated_data['type']

            sub_dir = f"uploads/{file_type}"
            storage = FileSystemStorage(
                location=os.path.join(settings.MEDIA_ROOT, sub_dir),
                base_url=f"{settings.MEDIA_URL}{sub_dir}/"
            )
            filename = storage.save(uploaded_file.name, uploaded_file)

            return Response({
                'message': 'Upload successful.',
                'download_url': f"/media/{sub_dir}/{filename}"
            }, status=status.HTTP_201_CREATED)

        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


#  Saves edits from ManualEditPage into the database

class SaveEditedAssignmentsAPIView(APIView):
    def post(self, request):
        try:
            data = request.data.get('data', [])
            if not data:
                return Response({'error': 'No data provided.'}, status=status.HTTP_400_BAD_REQUEST)

            saved_count = 0
            for row in data:
                course = row.get('course_number')
                professor = row.get('professor_name')

                if not course or not professor:
                    return Response({
                        'error': f'Missing Course Number or Professor Name in row: {row}'
                    }, status=status.HTTP_400_BAD_REQUEST)

                instance, created = GraderAssignment.objects.update_or_create(
                    course_number=course,
                    professor_name=professor,
                    defaults={
                        'assigned_grader': row.get('assigned_grader'),
                        'grader_major': row.get('grader_major'),
                        'grader_email': row.get('grader_email'),
                        'justification': row.get('justification'),
                    }
                )
                saved_count += 1

            return Response({'message': f'{saved_count} records saved successfully.'}, status=status.HTTP_200_OK)

        except Exception as e:
            import traceback
            traceback.print_exc()  # 👈 This will show the real error in terminal
            return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)



#  Returns match results from database for DisplayPage
class MatchResultsAPIView(APIView):
    def get(self, request):
        try:
            queryset = GraderAssignment.objects.all()
            serializer = GraderAssignmentSerializer(queryset, many=True)
            return Response({'data': serializer.data}, status=status.HTTP_200_OK)
        except Exception as e:
            return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
