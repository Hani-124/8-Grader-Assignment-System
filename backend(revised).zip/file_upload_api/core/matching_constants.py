# core/matching_constants.py

domain_to_skills = {
    "data science": [
        "pandas", "numpy", "scikit-learn", "tensorflow", "keras", "matplotlib",
        "seaborn", "r", "powerbi", "tableau", "excel", "sql", "jupyter", "statsmodels"
    ],
    "machine learning": [
        "tensorflow", "keras", "scikit-learn", "xgboost", "lightgbm", "deep learning",
        "pytorch", "ml", "neural network", "nlp", "computer vision", "reinforcement learning"
    ],
    "data analytics": [
        "powerbi", "tableau", "excel", "data mining"
    ],
    "business intelligence": [
        "powerbi", "tableau", "bi"
    ],
    "database": [
        "sql", "mysql", "postgresql", "mongodb", "oracle", "redis", "datastore"
    ],
    "data engineering": [
        "cassandra", "hadoop", "spark", "etl", "data warehousing"
    ],
    "web development": [
        "html", "css", "javascript", "react", "nodejs", "express", "php", "django", "flask",
        "web app", "frontend", "backend", "typescript", "angular", "vue", "ruby on rails",
        "bootstrap", "sass"
    ],
    "cloud": [
        "aws", "azure", "gcp", "cloud services"
    ],
    "devops": [
        "docker", "kubernetes", "jenkins", "terraform", "ansible", "ci/cd", "infrastructure"
    ],
    "systems": [
        "linux", "bash", "c", "cplusplus", "shell scripting", "kernel"
    ],
    "networking": [
        "cisco", "network protocols", "vpn", "firewalls", "wireshark"
    ],
    "cybersecurity": [
        "penetration testing", "nmap", "metasploit", "security auditing", "vulnerabilities", "ids/ips"
    ],
    "biomedical": [
        "biomedical", "ecg", "eeg", "medical imaging", "signal analysis",
        "biomedical signal analysis", "labview", "image processing", "signal filtering", "fourier analysis"
    ],
    "signal processing": [
        "signal", "matlab", "filtering", "fourier", "spectral"
    ],
    "visualization": [
        "charts", "dashboards", "visualization"
    ],
    "design": [
        "adobe photoshop", "illustrator", "indesign", "figma", "sketch", "canva",
        "ux/ui design", "wireframing", "prototyping"
    ],
    "scientific computing": [
        "simulink", "fortran", "comsol", "ansys", "solidworks", "autocad", "engineering simulations"
    ]
}
