from django.urls import path
from .views import (
    ResumeCourseProcessingAPI,
    StartAssignmentProcessAPIView,
    SaveEditedAssignmentsAPIView,
    MatchResultsAPIView,
    
)

urlpatterns = [
    path('api/process/', ResumeCourseProcessingAPI.as_view(), name='resume-course-processor'),
    path('api/start-matching/', StartAssignmentProcessAPIView.as_view(), name='start-matching'),
    path('api/update-grader-data/', SaveEditedAssignmentsAPIView.as_view(), name='save-edits'),
    path('api/match-results/', MatchResultsAPIView.as_view(), name='match-results'),
]
