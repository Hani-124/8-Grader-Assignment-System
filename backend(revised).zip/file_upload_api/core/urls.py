from django.urls import path
from .views import FileUploadAPI, SaveEditedAssignmentsAPIView, MatchResultsAPIView

urlpatterns = [
    path('api/upload/', FileUploadAPI.as_view(), name='file-upload'),
    path('api/update-grader-data/', SaveEditedAssignmentsAPIView.as_view(), name='save-edits'),
    path('api/match-results/', MatchResultsAPIView.as_view(), name='match-results'),
]
