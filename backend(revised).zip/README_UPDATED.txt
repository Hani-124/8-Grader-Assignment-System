
//runs server//

python manage.py makemigrations
python manage.py migrate
python manage.py runserver 0.0.0.0:80



make sure to change ALLOWED_HOST and CSRF_TRUSTED_ORIGINS in \backend\settings.py




Changes made:

seed_excel_to_mysql.py 
	- puts course_assignment_final_reasoned into sql
	- run to put data into sql

now displayPage and manualEditPage directly gets data from database and updates database
