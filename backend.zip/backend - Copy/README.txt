pip install djangorestframework django-cors-headers


//runs server//

python manage.py makemigrations
python manage.py migrate
python manage.py runserver


settings.py

update ALLOWED_HOST
	replace with ngrok backend


update CSRF_TRUSTED_ORIGINS
	update localhost from frontend
	update ngrok from ngrok frontend


// for frontend//

give ngrok backend http to frontend to change in /upload