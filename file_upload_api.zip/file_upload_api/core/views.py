from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from django.core.files.storage import FileSystemStorage
from django.conf import settings
import os

from .serializers import FileUploadSerializer

class FileUploadAPI(APIView):
    def post(self, request):
        serializer = FileUploadSerializer(data=request.data)
        if serializer.is_valid():
            uploaded_file = serializer.validated_data['file']
            file_type = serializer.validated_data['type']

            # Save to: media/uploads/<type>/<filename>
            sub_dir = f"uploads/{file_type}"
            storage = FileSystemStorage(
                location=os.path.join(settings.MEDIA_ROOT, sub_dir),
                base_url=f"{settings.MEDIA_URL}{file_type}/"
            )

            filename = storage.save(uploaded_file.name, uploaded_file)
            file_url = storage.url(filename)

            return Response({'download_url': file_url}, status=status.HTTP_201_CREATED)

        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        
        