from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from django.core.files.storage import FileSystemStorage
from django.conf import settings
import os
import pandas as pd
import numpy as np
import mysql.connector
import zipfile
from io import BytesIO
import fitz  # PyMuPDF
import re
import random

from .serializers import FileUploadSerializer


class FileUploadAPI(APIView):
    def post(self, request):
        serializer = FileUploadSerializer(data=request.data)
        if serializer.is_valid():
            uploaded_file = serializer.validated_data['file']
            file_type = serializer.validated_data['type'].lower()

            sub_dir = f"uploads/{file_type}"
            storage = FileSystemStorage(
                location=os.path.join(settings.MEDIA_ROOT, sub_dir),
                base_url=f"{settings.MEDIA_URL}{file_type}/"
            )

            filename = storage.save(uploaded_file.name, uploaded_file)
            file_path = os.path.join(settings.MEDIA_ROOT, sub_dir, filename)
            file_url = storage.url(filename)

            try:
                # Ensure database and tables exist
                create_database_if_not_exists("student")

                # Process file and insert data into students or courses table
                if filename.endswith(('.csv', '.xlsx', '.xls')) and file_type in ['candidates', 'courseinfo']:
                    df = pd.read_csv(file_path) if filename.endswith('.csv') else pd.read_excel(file_path)
                    df.columns = [str(col).strip().replace(" ", "_") for col in df.columns]
                    df = df.replace({np.nan: None})

                    table_map = {
                        "candidates": "students",
                        "courseinfo": "courses"
                    }
                    table_name = table_map.get(file_type)

                    if not table_name:
                        return Response({"error": "Invalid upload type for Excel/CSV"}, status=400)

                    insert_data_into_mysql(df, table_name)

                elif filename.endswith('.zip') and file_type == 'resume':
                    with zipfile.ZipFile(file_path, 'r') as zip_ref:
                        for zip_info in zip_ref.infolist():
                            if zip_info.filename.endswith('.pdf'):
                                pdf_data = zip_ref.read(zip_info.filename)
                                resumes = extract_resumes(BytesIO(pdf_data))
                                for resume_text in resumes:
                                    parsed = parse_resume_to_student_dict(resume_text, zip_info.filename)
                                    update_student_with_resume_data(parsed)

                # After inserting the data into the students and courses tables, assign students to courses based on keyword match
                self.assign_students_to_courses_based_on_keywords()

                return Response({
                    "message": f"{filename} processed and data inserted.",
                    "download_url": file_url
                }, status=status.HTTP_201_CREATED)

            except Exception as e:
                import traceback
                traceback.print_exc()
                return Response({"error": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def assign_students_to_courses_based_on_keywords(self):
        try:
            db = mysql.connector.connect(
                host="localhost",
                user="root",
                passwd="SeniorProject25",
                database="student"
            )
            cursor = db.cursor()

            # Fetch all students and courses
            cursor.execute("SELECT Student_ID, Skills FROM students")
            students = cursor.fetchall()

            cursor.execute("SELECT Course_Number, Course_Name, Keywords FROM courses")
            courses = cursor.fetchall()

            # Loop through each student and compare their skills with course keywords
            for student in students:
                student_id = student[0]
                student_skills = set(student[1].lower().split(", "))  # Convert skills to lowercase

                for course in courses:
                    course_number = course[0]
                    course_keywords = set(course[2].lower().split(", "))  # Convert keywords to lowercase

                    # Find the common skills/keywords between student and course
                    common_keywords = student_skills.intersection(course_keywords)

                    # If there are common keywords, assign the student to the course
                    if common_keywords:
                        self.insert_assigned_grader(student_id, course_number)

            db.commit()
            cursor.close()
            db.close()

        except Exception as e:
            print(f"Error assigning students to courses: {e}")

    def insert_assigned_grader(self, student_id, course_number):
        try:
            db = mysql.connector.connect(
                host="localhost",
                user="root",
                passwd="SeniorProject25",
                database="student"
            )
            cursor = db.cursor()

            # Check if the student is already assigned to the course
            cursor.execute("""
                SELECT COUNT(*) FROM assigned_grader 
                WHERE student_id = %s AND course_number = %s
            """, (student_id, course_number))

            # If the student is already assigned, skip the insertion
            if cursor.fetchone()[0] > 0:
                print(f"Student {student_id} is already assigned to course {course_number}. Skipping.")
                db.close()
                return

            # Ensure course_number exists in the courses table before inserting
            cursor.execute("SELECT COUNT(*) FROM courses WHERE Course_Number = %s", (course_number,))
            course_exists = cursor.fetchone()[0]
            if not course_exists:
                print(f"Course_Number {course_number} does not exist in the courses table.")
                db.close()
                return

            # Ensure student_id exists in the students table before inserting
            cursor.execute("SELECT COUNT(*) FROM students WHERE Student_ID = %s", (student_id,))
            student_exists = cursor.fetchone()[0]
            if not student_exists:
                print(f"Student_ID {student_id} does not exist in the students table.")
                db.close()
                return

            # Insert into assigned_grader
            cursor.execute("""
            INSERT INTO assigned_grader (student_id, course_number)
            VALUES (%s, %s)
            """, (student_id, course_number))

            db.commit()
            print(f"Assigned student_id={student_id} to course_number={course_number}")
            cursor.close()
            db.close()

        except Exception as e:
            print(f"Error inserting into assigned_grader: {e}")


def insert_data_into_mysql(df, table_name):
    db = mysql.connector.connect(
        host="localhost",
        user="root",
        passwd="SeniorProject25",
        database="student"
    )
    cursor = db.cursor()

    df.columns = [str(col).strip().replace(" ", "_") for col in df.columns]
    df = df.replace({np.nan: None})

    # Ensure table exists
    if "Student_ID" in df.columns:
        cursor.execute(f"CREATE TABLE IF NOT EXISTS `{table_name}` (Student_ID BIGINT PRIMARY KEY)")

    # Get current columns
    cursor.execute(f"SHOW COLUMNS FROM `{table_name}`")
    existing_columns = {row[0] for row in cursor.fetchall()}

    # Add any missing columns dynamically
    for col in df.columns:
        if col not in existing_columns:
            col_type = "VARCHAR(255)"
            if col == "Student_ID":
                continue  # already created
            cursor.execute(f"ALTER TABLE `{table_name}` ADD COLUMN `{col}` {col_type}")

    # Build and execute insert
    cols = ", ".join([f"`{col}`" for col in df.columns])
    vals = ", ".join(["%s"] * len(df.columns))
    update = ", ".join([f"`{col}`=VALUES(`{col}`)" for col in df.columns if col != 'Student_ID'])

    if "Student_ID" in df.columns:
        insert_query = f"INSERT INTO `{table_name}` ({cols}) VALUES ({vals}) ON DUPLICATE KEY UPDATE {update}"
    else:
        insert_query = f"INSERT INTO `{table_name}` ({cols}) VALUES ({vals})"

    for _, row in df.iterrows():
        cursor.execute(insert_query, tuple(row[col] for col in df.columns))

    db.commit()
    cursor.close()
    db.close()


def extract_resumes(pdf_file):
    doc = fitz.open(stream=pdf_file, filetype="pdf")
    text = "\n".join([page.get_text("text") for page in doc])
    return [text]


def parse_resume_to_student_dict(text, file_name=""):
    data = {}

    candidate_id_match = re.search(r"(\d+)(?=\D*$)", file_name)
    data["Student_ID"] = int(candidate_id_match.group(1)) if candidate_id_match else None

    lines = text.strip().split('\n')
    text_lower = text.lower()

    full_name = next((line.strip().title() for line in lines if "@" not in line and len(line.split()) >= 2), "Unknown Name")
    name_parts = full_name.split()
    data["Student_First_Name"] = name_parts[0]
    data["Student_Last_Name"] = name_parts[-1]

    email_match = re.search(r"[\w\.-]+@[\w\.-]+\b", text)
    data["Student_Email"] = email_match.group(0) if email_match else None

    year_match = re.search(r"\b(senior|junior|sophomore|freshman)\b", text_lower)
    data["Student_School_Year_Name"] = year_match.group(0).title() if year_match else None

    school_match = re.search(r"university of texas at dallas|ut dallas|utd", text_lower)
    data["Student_School"] = "UT Dallas" if school_match else None

    grad_match = re.search(r"(spring|fall|summer|winter)?\s?\d{4}", text_lower)
    data["Student_Graduation_Date"] = grad_match.group(0).title() if grad_match else None

    if "bachelor" in text_lower:
        data["Current_Qualification"] = "Bachelor's"
    elif "master" in text_lower:
        data["Current_Qualification"] = "Master's"
    elif "ph.d" in text_lower or "phd" in text_lower:
        data["Current_Qualification"] = "Ph.D"
    else:
        data["Current_Qualification"] = None

    majors = ["computer science", "software engineering", "data science", "electrical engineering", "information technology", "cybersecurity", "artificial intelligence", "business analytics"]
    data["Majors"] = next((m.title() for m in majors if m in text_lower), None)

    gpa_match = re.search(r"gpa[:\s]*([0-3]\.[0-9]{1,2}|4\.0)", text_lower)
    data["GPA"] = gpa_match.group(1) if gpa_match else None

    skill_keywords = ["python", "java", "sql", "machine learning", "data analysis", "react", "django", "c++", "javascript"]
    found_skills = [skill.title() for skill in skill_keywords if skill in text_lower]
    data["Skills"] = ", ".join(found_skills) if found_skills else None

    data["Student_Primary_College"] = None

    return data


def update_student_with_resume_data(data):
    db = mysql.connector.connect(
        host="localhost",
        user="root",
        passwd="SeniorProject25",
        database="student"
    )
    cursor = db.cursor()

    # Create table if it doesn't exist with just primary key
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS students (
        Student_ID BIGINT PRIMARY KEY,
        Student_First_Name VARCHAR(255),
        Student_Last_Name VARCHAR(255),
        Student_Email VARCHAR(255),
        Student_School_Year_Name VARCHAR(255),
        Student_School VARCHAR(255),
        Student_Graduation_Date VARCHAR(255),
        Current_Qualification VARCHAR(255),
        Majors VARCHAR(255),
        GPA VARCHAR(50),
        Skills TEXT,
        Student_Primary_College VARCHAR(255)
    )
    """)

    # Check existing columns
    cursor.execute("SHOW COLUMNS FROM students")
    existing_columns = {row[0] for row in cursor.fetchall()}

    # Add missing columns dynamically
    for key, value in data.items():
        if key not in existing_columns:
            if key == "Student_ID":
                continue
            column_type = "VARCHAR(255)" if isinstance(value, str) or value is None else "TEXT"
            cursor.execute(f"ALTER TABLE students ADD COLUMN `{key}` {column_type}")

    # Build and execute insert/update
    columns = ", ".join([f"`{key}`" for key in data])
    placeholders = ", ".join(["%s"] * len(data))
    update = ", ".join([f"`{key}`=VALUES(`{key}`)" for key in data if key != "Student_ID"])

    insert_query = f"""
    INSERT INTO students ({columns})
    VALUES ({placeholders})
    ON DUPLICATE KEY UPDATE {update}
    """

    cursor.execute(insert_query, tuple(data.values()))
    db.commit()
    cursor.close()
    db.close()


def create_database_if_not_exists(db_name):
    db = mysql.connector.connect(
        host="localhost",
        user="root",
        passwd="SeniorProject25"
    )
    cursor = db.cursor()
    
    # Create the database if it doesn't exist
    cursor.execute(f"CREATE DATABASE IF NOT EXISTS {db_name}")
    
    # Select the database
    cursor.execute(f"USE {db_name}")
    
    # Create the 'students' table if it doesn't exist
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS students (
        Student_ID BIGINT PRIMARY KEY,
        Student_First_Name VARCHAR(255),
        Student_Last_Name VARCHAR(255),
        Student_Email VARCHAR(255),
        Student_School_Year_Name VARCHAR(255),
        Student_School VARCHAR(255),
        Student_Graduation_Date VARCHAR(255),
        Current_Qualification VARCHAR(255),
        Majors VARCHAR(255),
        GPA VARCHAR(50),
        Skills TEXT,
        Student_Primary_College VARCHAR(255)
    )
    """)

    # Create the 'courses' table with Course Number instead of Course ID
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS courses (
        Course_Number INT PRIMARY KEY,  -- Changed from Course_ID to Course_Number
        Course_Name VARCHAR(255),
        Department VARCHAR(255),
        Professor_Name VARCHAR(255),
        Semester VARCHAR(50),
        Credits INT,
        Course_Description TEXT
    )
    """)

    # Create the 'assigned_grader' table with a unique constraint on (student_id, course_number)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS assigned_grader (
        id INT AUTO_INCREMENT PRIMARY KEY,
        student_id BIGINT NOT NULL,
        course_number INT NOT NULL,
        FOREIGN KEY (student_id) REFERENCES students(Student_ID),
        FOREIGN KEY (course_number) REFERENCES courses(Course_Number),
        UNIQUE (student_id, course_number)  -- Add this line for unique constraint
    )
    """)

    cursor.close()
    db.close()
