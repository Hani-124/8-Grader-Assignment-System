from django.urls import path
from .views import FileUploadAPI

urlpatterns = [
    path('api/upload/', FileUploadAPI.as_view(), name='api-upload'),
]
