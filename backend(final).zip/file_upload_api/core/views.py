# === Required Imports === #
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from django.core.files.storage import FileSystemStorage
from django.conf import settings
import os
import pandas as pd
import numpy as np
import mysql.connector
import zipfile
from io import BytesIO
import fitz  # PyMuPDF for reading PDFs
import re
from datetime import datetime
from sklearn.metrics.pairwise import cosine_similarity
from .models import GraderAssignment
from core.scrapers.utd_course_scraper import scrape_utd_courses  
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.feature_extraction import text
from core.matching_constants import domain_to_skills 


# ------------------------------------------------------------------------------------
# 1. Helper Functions
# ------------------------------------------------------------------------------------

# ✅ Initialize Database Schema: Students, Courses, Grader Assignments
# --------------------------------------------------------------------
# This function ensures the target MySQL database exists and creates the
# necessary tables if they do not already exist:
# - `students`: Stores all parsed and uploaded candidate data.
# - `courses`: Stores professor-course information and keyword metadata.
# - `assigned_grader`: Stores the final assignments of students to courses.
# --------------------------------------------------------------------
def create_database_if_not_exists(db_name):
    db = mysql.connector.connect(host="localhost", user="root", passwd="admin")
    cursor = db.cursor()
    cursor.execute(f"CREATE DATABASE IF NOT EXISTS {db_name}")
    cursor.execute(f"USE {db_name}")

    # Students table schema
    cursor.execute("""
       CREATE TABLE IF NOT EXISTS students (
        Application_ID VARCHAR(50) PRIMARY KEY,
        Timestamp DATETIME,
        Student_ID VARCHAR(50),
        First_Name VARCHAR(100),
        Last_Name VARCHAR(100),
        Email VARCHAR(100),
        Program_Level VARCHAR(50),
        Major VARCHAR(255),
        University VARCHAR(255),
        Graduation_Date DATE,
        GPA VARCHAR(10),
        Is_Qualified BOOLEAN,
        Resume_Skills TEXT,
        Resume_Education TEXT,
        Resume_Experience TEXT,
        Resume_Projects TEXT
    );
    """)

    # Courses table schema
    cursor.execute("""
         CREATE TABLE IF NOT EXISTS courses (
        Course_Number VARCHAR(50) PRIMARY KEY,
        Course_Name VARCHAR(255),
        Department VARCHAR(255),
        Professor_Name VARCHAR(255),
        Professor_Email VARCHAR(255),
        Section VARCHAR(50),
        Recommended_Student_Name VARCHAR(100),
        Recommended_Student_ID VARCHAR(50),
        Num_of_graders INT,
        Semester VARCHAR(50),
        Credits INT,
        Keywords TEXT,
        Course_Keywords TEXT
        )
    """)

    # Assignment table for matched results
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS assigned_grader (
            id INT AUTO_INCREMENT PRIMARY KEY,
            course_number VARCHAR(50),
            section VARCHAR(50),
            professor_name VARCHAR(255),
            assigned_grader VARCHAR(100),
            grader_major VARCHAR(100),
            grader_email VARCHAR(100),
            justification TEXT
    )
    """)

    cursor.close()
    db.close()


# ✅ Insert candidate list to students table in database
# ------------------------------------------------------------
# This function inserts or updates student records into the `students` table.
# - It dynamically adjusts column names and schema.
# - Automatically skips invalid or duplicate header rows.
# - Performs ON DUPLICATE KEY UPDATE using Application_ID as primary key.
# ------------------------------------------------------------
def insert_students_into_db(df, debug=False):
    import mysql.connector

    # === Step 0: Promote second row as header if needed === #
    first_row = list(df.iloc[0])
    if any("application" in str(cell).lower() for cell in first_row):
        print("📌 Detected export wrapper — promoting first row as header.")
        df.columns = first_row
        df = df.iloc[1:].copy()

    # === Step 1: Normalize all column names === #
    df.columns = [str(col).strip().replace("\u00A0", " ").replace(" ", "_") for col in df.columns]
    df.columns = [col.strip().lower() for col in df.columns]

    # === Step 2: Robust renaming === #
    rename_map = {}
    for col in df.columns:
        if "application_id" in col:
            rename_map[col] = "Application_ID"
        elif "student_id" in col:
            rename_map[col] = "Student_ID"
        elif "application" in col and "date" in col:
            rename_map[col] = "Timestamp"
        elif "first" in col and "name" in col:
            rename_map[col] = "First_Name"
        elif "last" in col and "name" in col:
            rename_map[col] = "Last_Name"
        elif "email" in col:
            rename_map[col] = "Email"
        elif "school_year" in col or "program_level" in col:
            rename_map[col] = "Program_Level"
        elif ("primary" in col and "college" in col) or ("college major" in col):
            rename_map[col] = "Major"
        elif re.search(r"\bstudent[_\s]?school\b", col): 
            rename_map[col] = "University"
        elif "graduation" in col:
            rename_map[col] = "Graduation_Date"
        elif "qualified" in col:
            rename_map[col] = "Is_Qualified"

    df.rename(columns=rename_map, inplace=True)

    # === Step 3: Normalize column names again === #
    df.columns = [col.strip().replace(" ", "_") for col in df.columns]
    df = df.replace({np.nan: None})

    # === Step 4: Keep only expected columns === #
    expected_columns = [
        "Application_ID", "Student_ID", "Timestamp", "First_Name", "Last_Name", "Email",
        "Program_Level", "Major", "University", "Graduation_Date", "GPA", "Is_Qualified",
        "Resume_Skills", "Resume_Education", "Resume_Experience", "Resume_Projects"
    ]
    df = df[[col for col in expected_columns if col in df.columns]]

    # === Step 5: Fix Timestamp format === #
    if "Timestamp" in df.columns:
        df["Timestamp"] = df["Timestamp"].apply(lambda x: str(x).replace(" UTC", "").strip() if x else None)

    # === Step 6: Connect and insert === #
    db = mysql.connector.connect(host="localhost", user="root", passwd="admin", database="student")
    cursor = db.cursor()

    non_key_columns = [col for col in df.columns if col != "Application_ID"]
    cols = ", ".join(f"`{col}`" for col in non_key_columns)
    placeholders = ", ".join(["%s"] * len(non_key_columns))
    update_clause = ", ".join(f"`{col}`=VALUES(`{col}`)" for col in non_key_columns)

    insert_query = f"""
        INSERT INTO students (Application_ID, {cols})
        VALUES (%s, {placeholders})
        ON DUPLICATE KEY UPDATE {update_clause}
    """

    inserted = 0
    for _, row in df.iterrows():
        app_id = row.get("Application_ID")
        try:
            app_id = str(int(float(app_id)))
        except:
            print(f"⚠️ Skipping invalid Application_ID: {app_id}")
            continue

        values = [app_id] + [row.get(col) for col in non_key_columns]
        values = [v.iloc[0] if isinstance(v, pd.Series) else v for v in values]
        if debug:
            print("⬆️ Inserting student:", app_id, values)
        cursor.execute(insert_query, values)
        inserted += 1

    db.commit()
    cursor.close()
    db.close()
    print(f"✅ Inserted or updated {inserted} student rows.")


# ✅ Insert Courses into MySQL from DataFrame
# ---------------------------------------------------------------
# - This function loads course information from an Excel/CSV file
# - Cleans column headers and renames Course_Number field
# - Recreates the 'courses' table dynamically based on columns
# - Inserts all rows into the `courses` table in MySQL
# ---------------------------------------------------------------
def insert_courses_into_db(df):
    import mysql.connector

    db = mysql.connector.connect(host="localhost", user="root", passwd="admin", database="student")
    cursor = db.cursor()

    # Normalize and clean column headers
    df.columns = [str(col).strip().replace(" ", "_") for col in df.columns]
    df = df.replace({np.nan: None})

    # Rename expected columns
    rename_map = {}
    for col in df.columns:
        if "course" in col.lower() and "number" in col.lower():
            rename_map[col] = "Course_Number"
        elif "recommended_student_id" in col.lower():
            rename_map[col] = "Recommended_Student_ID"

    df.rename(columns=rename_map, inplace=True)

    if "Course_Number" not in df.columns:
        raise ValueError("❌ No 'Course_Number' column found in course file.")

    # Skip accidental header row
    if all(str(df.iloc[0][col]).strip().lower() == col.lower() for col in df.columns):
        print("⚠️ Skipping duplicate header row in course file")
        df = df.iloc[1:].copy()

    # Ensure 'Keywords' column exists
    if "Keywords" not in df.columns:
        df["Keywords"] = None

    # Recreate the courses table
    cursor.execute("DROP TABLE IF EXISTS courses")
    cols_def = ", ".join([
        "`Keywords` TEXT" if col == "Keywords" else f"`{col}` VARCHAR(255)"
        for col in df.columns
    ])
    if "Recommended_Student_ID" not in df.columns:
        cols_def += ", `Recommended_Student_ID` VARCHAR(50)"  # Add it if missing

    cursor.execute(f"CREATE TABLE courses ({cols_def})")

    # Insert data
    cols = ", ".join(f"`{col}`" for col in df.columns)
    placeholders = ", ".join(["%s"] * len(df.columns))
    insert_query = f"INSERT INTO courses ({cols}) VALUES ({placeholders})"

    inserted = 0
    for _, row in df.iterrows():
        cursor.execute(insert_query, tuple(row[col] for col in df.columns))
        inserted += 1

    db.commit()
    cursor.close()
    db.close()
    print(f"✅ Inserted {inserted} course rows.")



# ✅ Extract Text from Resume PDF using PyMuPDF
# ---------------------------------------------------------------
# - Extracts raw text from all pages of a given PDF
# - Returns a single lowercase string for consistent parsing
# ---------------------------------------------------------------
def extract_resumes(pdf_file):
    doc = fitz.open(stream=pdf_file, filetype="pdf")
    text = "\n".join([page.get_text("text") for page in doc])
    return [text.lower()]


# ✅ Parse Resume Text into Student Dictionary
# ---------------------------------------------------------------
# - Converts plain resume text into structured student fields
# - Handles name, email, skills, education, and experience
# - Applies regex and heuristics to match typical resume formats
# ---------------------------------------------------------------
def parse_resume_to_student_dict(text, file_name=""):
    data = {}
    
    # === 0. Preprocess text === #
    lines = text.strip().split('\n')
    lines = [line.strip() for line in lines if line.strip() and not re.match(r"^[_\s]{5,}$", line)]
    text = "\n".join(lines)

      # === 1. Extract name from file name === #
    # Expected formats: firstname_lastname.pdf, FirstnameLastname_Resume.pdf, etc.
    name_part = os.path.splitext(os.path.basename(file_name))[0]  # remove extension
    name_part = re.sub(r'[^a-zA-Z_ ]', '', name_part)  # remove digits/special chars
    name_tokens = re.split(r"[_\s]+", name_part.strip())

    if len(name_tokens) >= 2:
        data["First_Name"] = name_tokens[0].title()
        data["Last_Name"] = name_tokens[1].title()
    else:
        data["First_Name"] = name_tokens[0].title() if name_tokens else "Unknown"
        data["Last_Name"] = "Unknown"

    # === 2. Extract Email === #
    email_match = re.search(r"[\w\.-]+@[\w\.-]+\b", text)
    data["Email"] = email_match.group(0) if email_match else None
   # === 3. Skills === #
    skill_block = ""

    # Primary regex match for SKILLS section (e.g., "Skills\n- Python\n- Java")
    skill_sections = re.findall(
    r"(skills|technical skills)\s*[:\-]?\s*(.+?)(?=\n{2,}|education|projects|experience|employment|certificates|languages|$)",
    text, re.DOTALL
    )
    if skill_sections:
        skill_block = ", ".join(section[1].replace('\n', ', ') for section in skill_sections)
    else:
        # Fallback: keyword match from known list
        skill_keywords = [
            "python", "java", "sql", "r", "c#", "c++", "react", "node", "excel", "powerbi",
            "tableau", "linux", "pandas", "numpy", "tensorflow", "keras", "django", "flask"
        ]
        found = [kw for kw in skill_keywords if kw.lower() in text.lower()]
        skill_block = ", ".join(set(found))  # set() removes duplicates

    # Final cleaning
    skill_block = re.sub(r"\b(details|links|languages|place of birth|nationality|license)\b", "", skill_block, flags=re.IGNORECASE)
    data["Resume_Skills"] = ", ".join(s.strip() for s in skill_block.split(",") if s.strip())

    # === 4. Education === #
    edu_match = re.search(r"education\s*(.+?)(skills|projects|experience|employment|certificates|languages|$)", text, re.DOTALL)
    if edu_match:
        edu_text = edu_match.group(1).strip()
        data["Resume_Education"] = edu_text

        if "master" in edu_text.lower():
            data["Program_Level"] = "Master's"
        elif "bachelor" in edu_text.lower():
            data["Program_Level"] = "Bachelor's"
        elif "ph.d" in edu_text.lower():
            data["Program_Level"] = "Ph.D"

        gpa_match = re.search(r"gpa[:\s]*([0-3]\.[0-9]{1,2}|4\.0)", edu_text, re.IGNORECASE)
        data["GPA"] = gpa_match.group(1) if gpa_match else None

    # === 5. Experience === #
    exp_match = re.search(r"(employment history|professional experience|experience)\s*(.+?)(education|skills|projects|certificates|languages|$)", text, re.DOTALL)
    if exp_match:
        data["Resume_Experience"] = exp_match.group(2).strip()

    # === 6. Graduation Date === #
    grad_match = re.search(r"(spring|fall|summer|winter)?\s?\d{4}", text)
    data["Graduation_Date"] = grad_match.group(0).title() if grad_match else None

    # === 7. University === #
    school_match = re.search(r"(ut dallas|university of texas at dallas)", text, re.IGNORECASE)
    data["University"] = "UT Dallas" if school_match else None

    # === 8. School Year === #
    year_match = re.search(r"\b(senior|junior|sophomore|freshman)\b", text, re.IGNORECASE)
    data["Student_School_Year_Name"] = year_match.group(1).title() if year_match else None

    # === 9. Empty placeholders === #
    data["Major"] = None
    data["Resume_Projects"] = None
    data["Is_Qualified"] = None
    print("🔍 Extracted skills:", data["Resume_Skills"], "from", file_name)
    return data


# ✅ Safe date conversion utility
# ---------------------------------------------------------
# Attempts to convert a raw date string or datetime object 
# to a standard `date` object. Returns None if it fails.
# ---------------------------------------------------------
def parse_date_safe(raw_date):
    try:
        if isinstance(raw_date, datetime):
            return raw_date.date()
        return datetime.strptime(str(raw_date).strip(), "%Y-%m-%d").date()
    except:
        return None


# ✅ Update or insert parsed resume data into the `students` table
# ---------------------------------------------------------
# - Uses Application_ID as primary key
# - Dynamically fills in resume-based fields (Skills, Education, Experience, GPA)
# - Uses ON DUPLICATE KEY UPDATE to merge resume info
# - Skips resume if Application_ID is missing or invalid
# ---------------------------------------------------------
def update_student_with_resume_data(parsed_data):
    try:
        first_name = parsed_data.get("First_Name")
        last_name = parsed_data.get("Last_Name")

        if not first_name or not last_name:
            print("⚠️ Skipping resume: Missing first or last name")
            return

        update_fields = {
            "Resume_Skills": parsed_data.get("Resume_Skills"),
            "Resume_Education": parsed_data.get("Resume_Education"),
            "Resume_Experience": parsed_data.get("Resume_Experience"),
            "Resume_Projects": parsed_data.get("Resume_Projects"),
            "GPA": parsed_data.get("GPA")
        }

        db = mysql.connector.connect(
            host="localhost", user="root", passwd="admin", database="student"
        )
        cursor = db.cursor()

        # === Check if student exists with that name === #
        cursor.execute("""
            SELECT Application_ID FROM students
            WHERE First_Name = %s AND Last_Name = %s
        """, (first_name, last_name))
        result = cursor.fetchone()

        if not result:
            print(f"❌ No student found with name: {first_name} {last_name}")
            return

        application_id = result[0]

        # === Build dynamic update query === #
        set_clause = ", ".join(f"`{key}` = %s" for key in update_fields.keys())
        update_query = f"""
            UPDATE students
            SET {set_clause}
            WHERE Application_ID = %s
        """

        values = list(update_fields.values()) + [application_id]
        cursor.execute(update_query, values)

        db.commit()
        cursor.close()
        db.close()
        print(f"✅ Updated resume info for {first_name} {last_name} (ID: {application_id})")

    except Exception as e:
        print(f"❌ Error updating student with resume: {e}")



# ✅ Sync course keywords from cs_courses to courses table
# --------------------------------------------------------
# This function updates the `courses` table by copying over keywords from the
# `cs_courses` table where `Course_Number` in `courses` matches `course_code` in `cs_courses`.
# It's used after scraping course descriptions and extracting keywords.
# --------------------------------------------------------
# ✅ Update the courses table with keywords from cs_courses using Course_Number match
def update_course_keywords_from_cs_courses():
    try:
        db = mysql.connector.connect(host="localhost", user="root", passwd="admin", database="student")
        cursor = db.cursor()

        # Step 1: Fetch all course_code → keywords from cs_courses
        cursor.execute("SELECT course_code, keywords FROM cs_courses")
        cs_keywords = {row[0].strip().upper(): row[1] for row in cursor.fetchall()}

        # Step 2: Ensure 'Course_Keywords' column exists in 'courses'
        cursor.execute("SHOW COLUMNS FROM courses LIKE 'Course_Keywords'")
        if not cursor.fetchone():
            cursor.execute("ALTER TABLE courses ADD COLUMN Course_Keywords TEXT")
            print("✅ Added 'Course_Keywords' column to 'courses' table.")

        # Step 3: Update Course_Keywords field in courses based on Course_Number match
        updated = 0
        for course_code, keyword_text in cs_keywords.items():
            cursor.execute("""
                UPDATE courses
                SET Course_Keywords = %s
                WHERE UPPER(Course_Number) = %s
            """, (keyword_text, course_code))
            if cursor.rowcount > 0:
                updated += 1

        db.commit()
        cursor.close()
        db.close()
        print(f"✅ Course_Keywords updated for {updated} courses.")

    except Exception as e:
        print(f"❌ Error updating Course_Keywords: {e}")

# ✅ Match students to courses (matching algorithm)
# --------------------------------------------------------------------------------------
# Logic:
# 1. Fetch student resume data (skills + experience) and course keyword metadata
# 2. Normalize all text (lowercasing, tech term fix: c++ → cplusplus, etc.)
# 3. Expand course keywords using domain-to-skill mapping (e.g., "data science" → ["pandas", "sql", ...])
# 4. Vectorize both student and course text using TF-IDF (with stopword filtering and token pattern tweaks)
# 5. Compute cosine similarity between each course and student
# 6. Assign each course to the most relevant student (1:1 unique match), skipping those already matched
# 7. If a course has a professor-recommended student, assign them directly
# 8. Save all assignments to the `assigned_grader` table with detailed justification
# --------------------------------------------------------------------------------------
def preprocess(text):
    return text.lower().strip()

def assign_students_to_courses():
    try:
        db = mysql.connector.connect(host="localhost", user="root", passwd="admin", database="student")
        cursor = db.cursor()

        # === Fetch data ===
        cursor.execute("SELECT * FROM courses")
        courses = pd.DataFrame(cursor.fetchall(), columns=[desc[0] for desc in cursor.description])

        cursor.execute("SELECT * FROM students")
        students = pd.DataFrame(cursor.fetchall(), columns=[desc[0] for desc in cursor.description])

        # === Ensure necessary columns exist ===
        for col in ["Course_Keywords", "Resume_Skills", "Resume_Experience", "Resume_Projects"]:
            if col not in courses.columns:
                courses[col] = ""
            if col not in students.columns:
                students[col] = ""

        def normalize_tech_terms(text):
            return (
                str(text).lower()
                .replace("c++", "cplusplus")
                .replace("c#", "csharp")
                .replace("node.js", "nodejs")
                .replace("react.js", "reactjs")
                .replace("express.js", "expressjs")
                .replace("vue.js", "vuejs")
                .replace(".", "")
            )

        def expand_keywords(text):
            tokens = str(text).lower().split()
            expanded = set(tokens)
            for domain, skills in domain_to_skills.items():
                if any(d in tokens for d in domain.split()):
                    expanded.update(skills)
            return " ".join(expanded)

        custom_stopwords = text.ENGLISH_STOP_WORDS.union({
            "and", "by", "in", "to", "on", "for", "of", "with", "at", "from", "into", "is", "the", "a", "an"
        }) - {"c", "r"}
        stopword_list = list(custom_stopwords)

        excluded_majors = {"erik jonsson school of engineering and computer science"}

        # === Preprocess ===
        courses["text"] = courses["Course_Keywords"].fillna("").apply(expand_keywords).apply(normalize_tech_terms)

        filtered_students = students[students["Resume_Skills"].str.strip().astype(bool)].reset_index(drop=True)
        filtered_students["text"] = (
            filtered_students["Resume_Skills"].fillna("") + " " +
            filtered_students["Resume_Experience"].fillna("") + " " +
            filtered_students["Resume_Projects"].fillna("")
        ).apply(normalize_tech_terms)

        # === TF-IDF + cosine similarity ===
        vectorizer = TfidfVectorizer(stop_words=stopword_list, token_pattern=r"(?u)\b\w+\b")
        tfidf = vectorizer.fit_transform(courses["text"].tolist() + filtered_students["text"].tolist())
        course_vecs = tfidf[:len(courses)]
        student_vecs = tfidf[len(courses):]
        similarity = cosine_similarity(course_vecs, student_vecs)

        # === Assignment logic ===
        assignments = []
        used_student_ids = set()

        for i, course_row in courses.iterrows():
            course_code = course_row["Course_Number"]
            section = course_row["Section"]
            professor = course_row["Professor_Name"]
            num_graders = int(course_row.get("Num_of_graders") or 1)
            course_keywords = set(course_row["text"].split()) - custom_stopwords
            assigned_count = 0

            # ✅ Handle multiple recommended students
            recommended_names = [n.strip() for n in str(course_row.get("Recommended_Student_Name") or "").split(",") if n.strip()]
            student_ids = [sid.strip() for sid in str(course_row.get("Recommended_Student_ID") or "").split(",") if sid.strip()]

            for ridx, sid in enumerate(student_ids):
                if assigned_count >= num_graders:
                    break
                student_row = students[students["Student_ID"].astype(str) == sid]
                name = recommended_names[ridx] if ridx < len(recommended_names) else f"Student_ID: {sid}"

                if not student_row.empty:
                    student = student_row.iloc[0]
                    used_student_ids.add(student["Application_ID"])
                    major = student["Major"]
                    justification = "Assigned by professor (Recommended Student)"
                    if str(major).strip().lower() not in excluded_majors:
                        justification += f" Grader major: {major}."
                    assignments.append({
                        "course_number": course_code,
                        "section": section,
                        "professor_name": professor,
                        "assigned_grader": f"{student['First_Name']} {student['Last_Name']}",
                        "grader_major": major,
                        "grader_email": student["Email"],
                        "justification": justification
                    })
                else:
                    assignments.append({
                        "course_number": course_code,
                        "section": section,
                        "professor_name": professor,
                        "assigned_grader": name,
                        "grader_major": None,
                        "grader_email": None,
                        "justification": "Assigned by professor (Recommended Student, not found in database)"
                    })
                assigned_count += 1

            # ✅ Fill remaining slots using cosine similarity
            sim_scores = similarity[i]
            ranked_indices = sim_scores.argsort()[::-1]

            for idx in ranked_indices:
                if assigned_count >= num_graders:
                    break

                student = filtered_students.iloc[idx]
                if student["Application_ID"] in used_student_ids:
                    continue

                used_student_ids.add(student["Application_ID"])
                score = sim_scores[idx]

                student_keywords = set(student["text"].split()) - custom_stopwords
                matched_keywords = course_keywords.intersection(student_keywords)
                major = student["Major"]

                course_domains = [
                    domain for domain, skills in domain_to_skills.items()
                    if any(skill in course_keywords for skill in skills)
                ]

                justification = (
                    f"Matched based on cosine similarity score of {score:.4f}. "
                    f"Shared keywords: {', '.join(sorted(matched_keywords)) or 'None'}."
                )
                if course_domains:
                    justification += f" Domain(s): {', '.join(sorted(set(course_domains)))}."
                if str(major).strip().lower() not in excluded_majors:
                    justification += f" Grader major: {major}."

                assignments.append({
                    "course_number": course_code,
                    "section": section,
                    "professor_name": professor,
                    "assigned_grader": f"{student['First_Name']} {student['Last_Name']}",
                    "grader_major": major,
                    "grader_email": student["Email"],
                    "justification": justification
                })
                assigned_count += 1

        # === Save assignments to DB ===
        cursor.execute("TRUNCATE TABLE assigned_grader")
        insert_query = """
            INSERT INTO assigned_grader (
                course_number, section, professor_name, assigned_grader,
                grader_major, grader_email, justification
            ) VALUES (%s, %s, %s, %s, %s, %s, %s)
        """
        for row in assignments:
            cursor.execute(insert_query, (
                row["course_number"],
                row["section"],
                row["professor_name"],
                row["assigned_grader"],
                row["grader_major"],
                row["grader_email"],
                row["justification"]
            ))

        db.commit()
        print(f"✅ Inserted {len(assignments)} total assignments.")

    except Exception as e:
        print("❌ Error during matching:", e)

    finally:
        if cursor: cursor.close()
        if db: db.close()


        
# ------------------------------------------------------------------------------------
# 2. API Views
# ------------------------------------------------------------------------------------
# 
class StartAssignmentProcessAPIView(APIView):
    def post(self, request):
        try:
            create_database_if_not_exists("student")

            # STEP 1: Load Excel files and insert into DB
            for file_type in ['candidates', 'courseInfo']:
                folder = os.path.join(settings.MEDIA_ROOT, f"uploads/{file_type}")
                latest_file = sorted(os.listdir(folder))[-1]
                file_path = os.path.join(folder, latest_file)
                df = pd.read_csv(file_path) if latest_file.endswith('.csv') else pd.read_excel(file_path)
                df.columns = [str(col).strip().replace(" ", "_") for col in df.columns]
                df = df.replace({np.nan: None})
                if file_type == "candidates":
                    insert_students_into_db(df)
                elif file_type == "courseInfo":
                    insert_courses_into_db(df)

            # STEP 2: Parse resumes from ZIP
            resume_folder = os.path.join(settings.MEDIA_ROOT, "uploads/resume")
            zip_files = [f for f in os.listdir(resume_folder) if f.endswith(".zip")]
            if zip_files:
                file_path = os.path.join(resume_folder, zip_files[-1])
                with zipfile.ZipFile(file_path, 'r') as zip_ref:
                    for zip_info in zip_ref.infolist():
                        if zip_info.filename.endswith('.pdf'):
                            pdf_data = zip_ref.read(zip_info.filename)
                            resumes = extract_resumes(BytesIO(pdf_data))
                            for resume_text in resumes:
                                parsed = parse_resume_to_student_dict(resume_text, zip_info.filename)
                                update_student_with_resume_data(parsed)

            # STEP 3: Run skill-based matching
            scrape_utd_courses()
            update_course_keywords_from_cs_courses()
            assign_students_to_courses()

            return Response({"message": "Matching completed successfully."}, status=200)

        except Exception as e:
            import traceback
            traceback.print_exc()
            return Response({"error": str(e)}, status=500)
        
# ✅ Main API to upload and process resumes, candidate info, course list
class ResumeCourseProcessingAPI(APIView):
    def post(self, request):
        try:
            file_map = {
                'resume': request.FILES.get('resume'),
                'candidates': request.FILES.get('candidates'),
                'courseInfo': request.FILES.get('courseInfo'),
            }

            for file_type, uploaded_file in file_map.items():
                if uploaded_file:
                    sub_dir = f"uploads/{file_type}"
                    storage = FileSystemStorage(location=os.path.join(settings.MEDIA_ROOT, sub_dir))
                    os.makedirs(storage.location, exist_ok=True)
                    storage.save(uploaded_file.name, uploaded_file)

            return Response({"message": "Files uploaded and stored successfully."}, status=201)

        except Exception as e:
            import traceback
            traceback.print_exc()
            return Response({"error": str(e)}, status=500)


# ✅ Save manual edits from frontend (DisplayPage / ManualEditPage)
class SaveEditedAssignmentsAPIView(APIView):
    def post(self, request):
        try:
            data = request.data.get('data', [])
            if not data:
                return Response({'error': 'No data provided.'}, status=400)

            connection = mysql.connector.connect(
                host='localhost',
                user='root',
                password='admin',
                database='student'
            )
            cursor = connection.cursor()

            for row in data:
                course = row.get('course_number')
                professor = row.get('professor_name')
                if not course or not professor:
                    return Response({'error': f'Missing Course Number or Professor Name in row: {row}'}, status=400)

                # 👇 Run update SQL
                cursor.execute("""
                    UPDATE assigned_grader
                    SET assigned_grader = %s,
                        grader_major = %s,
                        grader_email = %s,
                        justification = %s
                    WHERE course_number = %s AND professor_name = %s
                """, (
                    row.get('assigned_grader'),
                    row.get('grader_major'),
                    row.get('grader_email'),
                    row.get('justification'),
                    course,
                    professor
                ))

            connection.commit()
            return Response({'message': 'Records saved successfully.'}, status=200)

        except Exception as e:
            import traceback
            traceback.print_exc()
            return Response({'error': str(e)}, status=500)

        finally:
            if cursor: cursor.close()
            if connection: connection.close()

# ✅ Return all assigned match results to frontend
class MatchResultsAPIView(APIView):
    def get(self, request):
        try:
            connection = mysql.connector.connect(
                host='localhost',
                user='root',
                password='admin',
                database='student'
            )
            cursor = connection.cursor(dictionary=True)

            query = """
                SELECT 
                    ag.course_number,
                    ag.section,
                    ag.professor_name,
                    ag.assigned_grader,
                    ag.grader_major,
                    ag.grader_email,
                    ag.justification
                FROM assigned_grader ag
            """

            cursor.execute(query)
            result = cursor.fetchall()

            return Response({"data": result}, status=status.HTTP_200_OK)
        except mysql.connector.Error as e:
            return Response({"error": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        finally:
            if cursor: cursor.close()
            if connection: connection.close()

