from django.urls import path
from .views import FileUploadAPI, SaveEditedAssignmentsAPIView, MatchResultsAPIView,SeedDatabaseAPIView

urlpatterns = [
    path('api/upload/', FileUploadAPI.as_view(), name='file-upload'),
    path('api/seed/', SeedDatabaseAPIView.as_view(), name='seed-database'),
    path('api/update-grader-data/', SaveEditedAssignmentsAPIView.as_view(), name='save-edits'),
    path('api/match-results/', MatchResultsAPIView.as_view(), name='match-results'),
]
